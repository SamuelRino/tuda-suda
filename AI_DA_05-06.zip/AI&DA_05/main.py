import argparse
import csv
from datetime import datetime
from pathlib import Path

import matplotlib
import numpy as np
from scipy import interpolate, optimize, spatial, stats

matplotlib.use("Agg")
from matplotlib import pyplot as plt


ROOT = Path(__file__).resolve().parent
BASE = (0, 0)


def read_rows(filename):
    with (ROOT / "data" / filename).open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def draw_plan(path, sections, points, selected):
    fig, ax = plt.subplots(figsize=(6, 5), layout="constrained")
    for section, (x, y), used in zip(sections, points, selected):
        color = "tab:green" if used else "tab:gray"
        if used:
            ax.plot([BASE[0], x], [BASE[1], y], "--", color=color, alpha=0.5)
        ax.scatter(x, y, color=color, zorder=3)
        ax.annotate(section["section_id"], (x, y), xytext=(6, 4), textcoords="offset points")
    ax.scatter(*BASE, color="black", marker="s", zorder=3)
    ax.annotate("База", BASE, xytext=(-8, -12), textcoords="offset points", ha="right")
    ax.set(title="Выбранные участки выделены зелёным", xlabel="X, км", ylabel="Y, км", aspect="equal")
    ax.grid(alpha=0.25)
    ax.margins(0.18)
    fig.savefig(path, dpi=150)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description="Размещение дорожных детекторов")
    parser.add_argument("--detectors", type=int, default=3)
    parser.add_argument("--budget-km", type=float, default=38)
    args = parser.parse_args()
    if args.detectors < 0 or not np.isfinite(args.budget_km) or args.budget_km < 0:
        parser.error("Количество детекторов и лимит пробега должны быть неотрицательными.")

    sections = read_rows("sections.csv")
    pilot = read_rows("pilot_counts.csv")
    times = sorted({row["timestamp"] for row in pilot})
    hours = np.array([datetime.fromisoformat(time).hour for time in times])
    measurements = {
        (row["section_id"], row["timestamp"]): float(row["vehicles"] or "nan")
        for row in pilot
    }
    counts = np.array([
        [measurements[section["section_id"], time] for time in times]
        for section in sections
    ])

    # Восстанавливаем пропуск по двум соседним замерам.
    for section, row in zip(sections, counts):
        known = np.isfinite(row)
        if known.all():
            continue
        line = interpolate.interp1d(hours[known], row[known], kind="linear", bounds_error=True)
        row[~known] = line(hours[~known])
        for hour, value in zip(hours[~known], row[~known]):
            print(f'{section["section_id"]}, {hour:02d}:00 — восстановлено {value:.1f} авт./ч')

    # Строки матрицы соответствуют участкам, столбцы — часам замеров.
    summary = stats.describe(counts, axis=1)
    means = summary.mean
    deviations = np.sqrt(summary.variance)
    points = np.array([(float(row["x_km"]), float(row["y_km"])) for row in sections])
    trip_km = 2 * spatial.distance.cdist([BASE], points)[0]

    # 0 или 1 детектор на участок. Отрицательные средние превращают минимум в максимум.
    limits = optimize.LinearConstraint(
        [np.ones(len(sections)), trip_km], [0, 0], [args.detectors, args.budget_km]
    )
    plan = optimize.milp(
        c=-means, integrality=np.ones(len(sections)), bounds=optimize.Bounds(0, 1),
        constraints=limits, options={"mip_rel_gap": 0},
    )
    if not plan.success:
        raise RuntimeError(plan.message)
    selected = plan.x > 0.5

    results = ROOT / "results"
    results.mkdir(exist_ok=True)
    with (results / "placement.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow([
            "section_id", "name", "mean_vehicles_per_hour", "std_vehicles_per_hour", "round_trip_km", "selected"
        ])
        for section, mean, deviation, distance, used in zip(sections, means, deviations, trip_km, selected):
            writer.writerow([
                section["section_id"], section["name"], f"{mean:.2f}", f"{deviation:.2f}",
                f"{distance:.2f}", int(used),
            ])
    draw_plan(results / "placement.png", sections, points, selected)

    chosen = [section["section_id"] for section, used in zip(sections, selected) if used]
    print("Выбраны участки:", ", ".join(chosen) or "нет")
    print(f"Пробег: {trip_km[selected].sum():.2f} из {args.budget_km:.2f} км")
    print(f"Суммарный средний поток: {means[selected].sum():.2f} авт./ч")


if __name__ == "__main__":
    main()
