import numpy as np
import matplotlib.pyplot as plt
from scipy import interpolate, optimize, spatial, stats

sections = ["A01", "A02", "A03", "A04", "A05", "A06"]
points = np.array([[3.5, 5.5], [7, 5], [0, 6], [-8, -8], [4, -3], [-4, 3]])

# Учебные замеры. Строка — участок, столбец — час.
hours = np.array([8, 9, 10])
traffic = np.array([
    [908, float("nan"), 569],
    [1314, 1311, 1057],
    [606, 540, 371],
    [1502, 1551, 1286],
    [1100, 1013, 879],
    [966, float("nan"), 644]
])

for section, counts in zip(sections, traffic):
    missing = np.isnan(counts)
    if missing.any():
        line = interpolate.interp1d(hours[~missing], counts[~missing])
        counts[missing] = line(hours[missing])
        for hour, value in zip(hours[missing], counts[missing]):
            print(f"{section}, {hour:02d}:00: восстановлено {value:.1f} авт./ч")

average = stats.tmean(traffic, axis=1)
distance = 2 * spatial.distance.cdist([[0, 0]], points)[0]

# Не больше трёх детекторов, пробег от базы и обратно не больше 38 км.
limits = optimize.LinearConstraint([np.ones(len(sections)), distance], [0, 0], [3, 38])
plan = optimize.milp(
    -average,  # Минус нужен, чтобы найти максимум среднего потока.
    integrality=np.ones(len(sections), dtype=int),
    bounds=optimize.Bounds(0, 1),
    constraints=limits,
    options={"mip_rel_gap": 0}
)
if not plan.success:
    raise RuntimeError(plan.message)

selected = plan.x > 0.5
print()
print("Участки для установки:")
for section, km, flow, used in zip(sections, distance, average, selected):
    if used:
        print(f"{section}: {km:.2f} км, {flow:.2f} авт./ч")
print(f"Общий пробег: {distance[selected].sum():.2f} км")
print(f"Суммарный средний поток: {average[selected].sum():.2f} авт./ч")

plt.scatter(points[:, 0], points[:, 1], c=np.where(selected, "green", "gray"))
plt.scatter(0, 0, c="black", marker="s", label="База")
for section, point in zip(sections, points):
    plt.annotate(section, point, xytext=(5, 5), textcoords="offset points")
plt.title("Размещение детекторов (зелёные точки)")
plt.xlabel("X, км")
plt.ylabel("Y, км")
plt.axis("equal")
plt.grid(alpha=0.3)
plt.legend()
plt.tight_layout()
plt.show()
