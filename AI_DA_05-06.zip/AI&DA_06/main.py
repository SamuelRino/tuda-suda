import pandas as pd
import matplotlib.pyplot as plt

# 20 учебных замеров на Центральном проспекте (A02).
data = {
    "Дата": ["2025-09-01"] * 6 + ["2025-09-02"] * 6 + ["2025-09-06"] * 3 + ["2025-09-08"] * 5,
    "Час": [7, 8, 9, 10, 11, 12, 7, 8, 9, 10, 11, 12, 8, 9, 10, 7, 8, 9, 10, 11],
    "Автомобили": [
        1187, 1314, 1311, 1057, 850, 812,
        1195, 1272, 1339, 1163, 893, 850,
        439, 654, 703,
        1150, 1283, 1288, 1014, 777
    ]
}

df = pd.DataFrame(data)
df["Дата"] = pd.to_datetime(df["Дата"])
df["Тип дня"] = (df["Дата"].dt.day_of_week >= 5).map({True: "Выходные", False: "Будни"})
print(df.to_string(index=False))
print()

flow = df.groupby(["Час", "Тип дня"])["Автомобили"].mean().unstack()
print("Средний поток с 08:00 до 11:00:")
print(flow.loc[8:10].mean().round(1))
print(f"Час пик в будни: {flow['Будни'].idxmax():02d}:00")
print()

# Последний день оставляем для проверки прогноза.
last_date = df["Дата"].max()
train = df[df["Дата"] < last_date]
test = df[df["Дата"] == last_date].copy()
weekday_average = train[train["Тип дня"] == "Будни"].groupby("Час")["Автомобили"].mean()
test["Прогноз"] = test["Час"].map(weekday_average)
print(f"Проверка прогноза за {last_date:%d.%m.%Y}:")
print(test[["Час", "Автомобили", "Прогноз"]].to_string(index=False))
error = (test["Прогноз"] - test["Автомобили"]).abs().mean()
print(f"Средняя абсолютная ошибка: {error:.1f} авт./ч")

next_hour = test["Час"].max() + 1
forecast = round(weekday_average[next_hour])
print(f"Прогноз на {next_hour:02d}:00: {forecast} автомобилей за час")

plt.plot(flow.index, flow["Будни"], "o-", label="Будни")
plt.plot(flow.index, flow["Выходные"], "o-", label="Выходные")
plt.title("Движение на Центральном проспекте")
plt.xlabel("Час")
plt.ylabel("Автомобилей за час")
plt.xticks(flow.index)
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()
