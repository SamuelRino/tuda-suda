from pathlib import Path

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
from matplotlib import pyplot as plt


ROOT = Path(__file__).resolve().parent
DATE_FORMAT = "%Y-%m-%dT%H:%M"
SECTION = "A02"


def average_by_hour(data):
    return data.groupby(["weekend", "hour"])["vehicles"].mean()


def predict(profile, timestamps):
    # Находим средний поток для того же часа и типа дня.
    return [profile.loc[(time.weekday() >= 5, time.hour)] for time in timestamps]


def draw_profile(path, profile, section):
    fig, ax = plt.subplots(figsize=(7, 4), layout="constrained")
    for weekend, label in ((False, "Будни"), (True, "Выходные")):
        hours = profile.loc[weekend]
        ax.plot(hours.index, hours, "o-", label=label)
    ax.set(title=f"Средний поток на участке {section}", xlabel="Час", ylabel="Автомобилей за час")
    ax.set_xticks(sorted(profile.index.get_level_values("hour").unique()))
    ax.grid(alpha=0.25)
    ax.legend()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def draw_forecast(path, predictions):
    labels = predictions.index.strftime("%H:%M")
    fig, ax = plt.subplots(figsize=(7, 4), layout="constrained")
    ax.plot(labels, predictions["actual"], "o-", label="Замер")
    ax.plot(labels, predictions["hourly_average"], "o--", label="Прогноз")
    ax.set(
        title=f"Проверка прогноза за {predictions.index[0]:%d.%m.%Y}",
        xlabel="Час",
        ylabel="Автомобилей за час",
    )
    ax.grid(alpha=0.25)
    ax.legend()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def main():
    data = pd.read_csv(ROOT / "data" / "traffic.csv", parse_dates=["timestamp"])
    data = data[data["section_id"] == SECTION].sort_values("timestamp")
    if data.empty:
        raise ValueError(f"В датасете нет замеров для участка {SECTION}.")
    data["day"] = data["timestamp"].dt.normalize()
    data["hour"] = data["timestamp"].dt.hour
    data["weekend"] = data["timestamp"].dt.day_of_week >= 5

    test_day = data["day"].max()
    train = data[data["day"] < test_day]
    test = data[data["day"] == test_day]
    same_type = train[train["weekend"] == test["weekend"].iat[0]]
    last_day = same_type[same_type["day"] == same_type["day"].max()]

    predictions = test.set_index("timestamp")[["vehicles"]].rename(columns={"vehicles": "actual"})
    predictions["last_same_day_type"] = predict(average_by_hour(last_day), predictions.index)
    predictions["hourly_average"] = predict(average_by_hour(train), predictions.index)

    scores = []
    for method in ("last_same_day_type", "hourly_average"):
        error = predictions[method] - predictions["actual"]
        scores.append({
            "model": method,
            "mae_vehicles": error.abs().mean(),
            "rmse_vehicles": np.sqrt((error ** 2).mean()),
        })
    metrics = pd.DataFrame(scores)

    profile = average_by_hour(data)
    next_hour = data["timestamp"].max() + pd.Timedelta(hours=1)
    forecast = round(predict(profile, [next_hour])[0])
    comparison = profile.unstack(level="weekend").dropna().mean()
    print(f"Участок {SECTION}. Всего {len(data)} замеров, для проверки выделено {len(test)}.")
    print(f"Средний поток за общие часы — будни: {comparison[False]:.1f}, выходные: {comparison[True]:.1f} авт./ч")
    print(metrics.to_string(index=False, float_format=lambda value: f"{value:.2f}"))
    print(f"Прогноз на {next_hour:%d.%m.%Y %H:%M} — {forecast} автомобилей.")

    results = ROOT / "results"
    results.mkdir(exist_ok=True)
    predictions.to_csv(results / "forecasts.csv", date_format=DATE_FORMAT, lineterminator="\n")
    metrics.to_csv(results / "metrics.csv", index=False, float_format="%.2f", lineterminator="\n")
    pd.DataFrame([{
        "timestamp": next_hour.strftime(DATE_FORMAT), "section_id": SECTION, "vehicles_forecast": forecast
    }]).to_csv(results / "next_hour.csv", index=False, lineterminator="\n")
    draw_profile(results / "traffic_profile.png", profile, SECTION)
    draw_forecast(results / "forecast.png", predictions)


if __name__ == "__main__":
    main()
