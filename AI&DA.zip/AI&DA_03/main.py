import numpy as np
import matplotlib.pyplot as plt

rooms = ["25","44","27","30","21","24"]

men = np.array([12, 8, 15, 10, 6, 14])
women = np.array([10, 16, 7, 12, 18, 8])

print("Количество людей по кабинетам:")
for room, m, w in zip(rooms,men,women):
    print(f"Кабинет {room}: мужчин - {m}, женщин - {w}")
print()

x = np.arange(len(rooms))
width= 0.35

plt.figure(figsize=(10,5))
plt.bar(x - width/2, men, width, label="Мужчины")
plt.bar(x + width/2, women, width, label="Женщины")

plt.xticks(x, rooms)
plt.xlabel("Кабинеты")
plt.ylabel("Количество человек")
plt.legend()
plt.grid(axis="y", alpha=0.3)

plt.show()



total_men = np.sum(men)
total_women = np.sum(women)

plt.figure(figsize=(7,7))

plt.pie(
    [total_men,total_women],
    labels=["Мужчин","Женщин"],
    autopct="%1.1f%%",
    startangle=90
)

plt.show()



fig, axes = plt.subplots(1,3,figsize=(17,5))

axes[0].bar(x - width/2, men, width, label="Мужчины")
axes[0].bar(x + width/2, women, width, label="Женщины")

axes[0].set_xticks(x, rooms)
axes[0].legend()

axes[1].pie(
    [total_men,total_women],
    labels=["Мужчин","Женщин"],
    autopct="%1.1f%%",
    startangle=90
)

total = men + women

axes[2].plot(rooms, total, marker="o")
axes[2].set_ylabel("Количество человек")
axes[2].grid(alpha=0.3)

plt.tight_layout()
plt.show()