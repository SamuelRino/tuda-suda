import seaborn as sb
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

diamonds = sb.load_dataset("diamonds")

print("Первые пять записей:")
print(diamonds.head())
print()

print("Инфо о датасете:")
print(diamonds.info())
print()

print("Статистика:")
print(diamonds.describe())
print()

print("Пропущенные значения")
print(diamonds.isnull().sum())
print()



plt.figure(figsize=(10,5))
sb.countplot(data=diamonds,x='cut',order=["Fair","Good","Very Good", "Premium", "Ideal"])

plt.title("По качеству огранки")
plt.xlabel("Качество")
plt.ylabel("Количество")

plt.tight_layout()
plt.show()



plt.figure(figsize=(10,5))

sb.histplot(data=diamonds,x="price",bins=50,kde=True)

plt.title("По ценам")
plt.xlabel("Цена в долларах")
plt.ylabel("Количество")

plt.tight_layout()
plt.show()



plt.figure(figsize=(10,6))

sb.scatterplot(data=diamonds,x="carat",y="price",hue="cut",alpha=0.4)

plt.title("Зависимость цены от массы")
plt.xlabel("Масса в каратах")
plt.ylabel("Цена в долларах")

plt.tight_layout()
plt.show()



numeric_data = diamonds.select_dtypes(include=np.number)
corellation = numeric_data.corr()

plt.figure(figsize=(9,7))

sb.heatmap(corellation, annot=True, cmap="coolwarm",fmt='.2f')

plt.title("Корреляция")

plt.tight_layout()
plt.show()